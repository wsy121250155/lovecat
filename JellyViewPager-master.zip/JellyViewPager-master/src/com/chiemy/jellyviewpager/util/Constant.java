package com.chiemy.jellyviewpager.util;

import com.chiemy.jellyviewpager.R;
import com.chiemy.jellyviewpager.R.drawable;

public class Constant {
	public static final String KEY = "image";
	
	public static int [] images = {R.drawable.a,R.drawable.b,
			R.drawable.c,R.drawable.d,R.drawable.e};
	
}
